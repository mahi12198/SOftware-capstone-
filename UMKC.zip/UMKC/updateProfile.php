<?php
session_start();
include("db_connect.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentId = $_SESSION['student_id'];

    // Collect form data and validate
    $name = mysqli_real_escape_string($connection, $_POST['name']); 
    $lastname = mysqli_real_escape_string($connection, $_POST['lastname']);
    $mailid = mysqli_real_escape_string($connection, $_POST['mailid']);
    $phone = mysqli_real_escape_string($connection, $_POST['phone']);
    $date_of_birth = mysqli_real_escape_string($connection, $_POST['date_of_birth']); 
    $toefl_score = mysqli_real_escape_string($connection, $_POST['toefl_score']); 
    $grad_asst_score = mysqli_real_escape_string($connection, $_POST['grad_asst_score']); 
    $graduation_level = mysqli_real_escape_string($connection, $_POST['graduation_level']);
    $major = mysqli_real_escape_string($connection, $_POST['major']);

    // Validate graduation level (should be either Undergraduate or Graduate)
    $allowedGradLevels = array('Undergraduate', 'Graduate');
    if (!in_array($graduation_level, $allowedGradLevels)){
        echo "Invalid Graduation Level";
        exit();
    }

    // Validate major (adjust the list based on your specific majors)
    $allowedMajors = array('Computer Science', 'Engineering');
    if (!in_array($major, $allowedMajors)){
        echo "Invalid Major";
        exit();
    }

    // Validate phone number (numeric, 10 digits)
    if (!preg_match("/^[0-9]{10}$/", $phone)) {
        echo "Invalid phone number format";
        exit();
    }

    // Validate TOEFL score (optional, adjust range as needed)
    if ($toefl_score !== '' && ($toefl_score < 0 || $toefl_score > 120)) {
        echo "Invalid TOEFL Score";
        exit();
    }

    // Validate Grad Assistant Score (optional, adjust the range as needed)
    if ($grad_asst_score !== '' && ($grad_asst_score < 0 || $grad_asst_score > 100)) {
        echo "Invalid Grad Assistant Score";
        exit();
    }

    // Validate date of birth (YYYY-MM-DD format)
    $dobDateTime = DateTime::createFromFormat('Y-m-d', $date_of_birth);
    if (!$dobDateTime || $dobDateTime->format('Y-m-d') !== $date_of_birth) {
        echo "Invalid date of birth format";
        exit();
    }

    // Update user data in the database using a prepared statement
    $query = "UPDATE regstudent SET name=?, lastname=?, mailid=?, phone=?, date_of_birth=?, toefl_score=?, grad_asst_score=?, graduation_level=?, major=? WHERE id=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "sssssssssi", $name, $lastname, $mailid, $phone, $date_of_birth, $toefl_score, $grad_asst_score, $graduation_level, $major, $studentId);

    if (mysqli_stmt_execute($stmt)) {
        // Update successful, redirect to the profile page
        header("Location: success_std_register.php");
        exit();
    } else {
        // Update failed, handle the error
        echo "Error updating profile: " . mysqli_error($connection);
    }

    mysqli_stmt_close($stmt);
}
?>
