<?php
// Start the session to access session variables
session_start();
// Include the database connection file
include("db_connect.php");
// Fetch student data from the database
$studentId = $_SESSION['student_id']; // Assuming you store student ID in the session
$query = "SELECT * FROM regstudent WHERE id = $studentId";
$result = mysqli_query($connection, $query);
// Check for errors in the query
if (!$result) {
    die("Query failed: " . mysqli_error($connection));
}
// Check if any rows were returned
if (mysqli_num_rows($result) == 0) {
    die("No data found for id: $studentId");
}
// Store the fetched data in an array
$userData = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Graduate Training Project- Profile Page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
            display: flex;
            margin: 0;
            flex-direction: column;
            padding-top: 39px;
        }

        .register-panel {
            margin-top: 100px;
        }
    </style>
</head>

<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
        <a class="navbar-brand text-white" href="index.php" style="padding-left: 45px;">
            <img src="images/umkc.png" alt="Logo" width="270" height="70">
        </a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white" href="applyJob.php">Job Apply</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="searchJob.php">Search Job</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="appliedJobs.php">Applied Job</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="studentProfile.php">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    <!-- Content of the profile page  -->
    <div class="container register-panel">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center text-dark">Student Profile</h4>
                        <form action="updateProfile.php" method="post">
                            <div class="form-group">
                                <label class="labels">First Name:</label><input type="text" class="form-control"
                                    id="name" name="name" value="<?php echo $userData['name']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="labels">Last Name:</label><input type="text" class="form-control"
                                    id="lastname" name="lastname" value="<?php echo $userData['lastname']; ?>">
                            </div>
                            <div class="form-group">
                                <label class="labels">Phone Number:</label><input type="tel" class="form-control"
                                    id="phone" name="phone" value="<?php echo $userData['phone']; ?>" required>
                            </div>

                            <div class="form-group">
                                <label class="labels">Date of Birth:</label><input type="date" class="form-control"
                                    id="date_of_birth" name="date_of_birth"
                                    value="<?php echo $userData['date_of_birth']; ?>">
                            </div>
                            <div class="form-group">
                                <label class="labels">Toefl Score:</label><input type="number" class="form-control"
                                    id="toefl_score" name="toefl_score" value="<?php echo $userData['toefl_score']; ?>">
                            </div>
                            <div class="form-group">
                                <label class="labels">Grad Assistant Score: </label><input type="number"
                                    class="form-control" id="grad_asst_score" name="grad_asst_score"
                                    value="<?php echo $userData['grad_asst_score']; ?>">
                            </div>
                            <div class="form-group">
                                <label class="labels">Email:</label><input type="text" class="form-control" id="mailid"
                                    name="mailid" value="<?php echo $userData['mailid']; ?>">
                            </div>
                            <div class="form-group">
                                <label class="labels">Major:</label>
                                <select name="major" id="major" class="form-control">
                                    <option value="Computer Science" <?php if ($userData['major'] == 'Computer Science')
                                        echo 'selected'; ?>>Computer Science</option>
                                    <option value="Engineering" <?php if ($userData['major'] == 'Engineering')
                                        echo 'selected'; ?>>Engineering</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="labels">Graduation Level:</label>
                                <select name="graduation_level" id="graduation_level" class="form-control">
                                    <option value="Undergraduate" <?php if ($userData['graduation_level'] == 'Undergraduate')
                                        echo 'selected'; ?>>
                                        Undergraduate</option>
                                    <option value="Graduate" <?php if ($userData['graduation_level'] == 'Graduate')
                                        echo 'selected'; ?>>Graduate</option>
                                </select>
                            </div>
                            <div class="mt-5 text-center"><button class="btn btn-outline-primary" type="submit">Update
                                    Profile</button></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>