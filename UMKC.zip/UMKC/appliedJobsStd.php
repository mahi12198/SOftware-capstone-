<?php
// Start the session to access session variables
session_start();

// Check if faculty is logged in
if (!isset($_SESSION['faculty_email'])) {
    // If not logged in, redirect to faculty login page
    header("Location: facultylogin.php");
    exit();
}

// Include the database connection file
include("db_connect.php");

// Function to display applied jobs by a specific student
function displayAppliedJobs($connection, $studentId)
{
    $sql = "SELECT jobs.jobtitle, jobs.graduation, jobs.skillrequired, jobs.graduateStd, jobs.contact_details, jobs.profile, jobs.company, jobs.place, job_applications.resume, job_applications.status,job_applications.id
            FROM jobs
            INNER JOIN job_applications ON jobs.id = job_applications.job_id
            INNER JOIN regstudent ON job_applications.student_id = regstudent.id
            WHERE regstudent.id = $studentId";

    $result = mysqli_query($connection, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<tr>';
            echo '<td>' . $row['jobtitle'] . '</td>';
            echo '<td>' . $row['graduation'] . '</td>';
            echo '<td>' . $row['skillrequired'] . '</td>';
            echo '<td>' . $row['graduateStd'] . '</td>';
            echo '<td>' . $row['contact_details'] . '</td>';
            echo '<td>' . $row['profile'] . '</td>';
            echo '<td>' . $row['company'] . '</td>';
            echo '<td>' . $row['place'] . '</td>';
            echo '<td><a href="' . $row['resume'] . '" class="btn btn-success btn-sm" download>Download Resume</a></td>';
            echo '<td>';
            if ($row['status'] == 0) {
                echo '<span class="badge badge-warning">Not Reviewed</span>';
            } else {
                echo '<span class="badge badge-success">Reviewed</span>';
            }
            echo '</td>';
            echo '<td>';
            if ($row['status'] == 0) {
                echo '<a href="review_application.php?application_id=' . $row['id'] . '" class="btn btn-primary btn-sm">Review</a>';
            } else {
                echo '<span class="badge badge-success">Reviewed</span>';
            }
            echo '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="10" class="text-center">No applied jobs found.</td></tr>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Your Graduate Training Project - Applied Jobs</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
        }

        .applied-jobs-panel {
            margin-top: 100px;
        }
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
        <a class="navbar-brand text-white" href="faculty_dashboard.php" style="padding-left: 45px;">
            <img src="images/umkc.png" alt="Logo" width="270" height="70">
        </a>
    </nav>

    <!-- Applied Jobs Panel -->
    <div class="container applied-jobs-panel">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center">Applied Jobs</h4>

                        <!-- Applied Jobs Table -->
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Job Title</th>
                                        <th>Graduation Level</th>
                                        <th>Skill Required</th>
                                        <th>Graduate Students</th>
                                        <th>Contact Details</th>
                                        <th>Profile</th>
                                        <th>Company</th>
                                        <th>Place</th>
                                        <th>Resume</th> <!-- New column for resume download link -->
                                        <th>Status</th> <!-- New column for status -->
                                        <th>Action</th> <!-- New column for action -->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Check if student ID is set in the URL
                                    if (isset($_GET['id'])) {
                                        $studentId = $_GET['id'];
                                        // Display applied jobs by the specific student
                                        displayAppliedJobs($connection, $studentId);
                                    } else {
                                        echo '<tr><td colspan="10" class="text-center">Student ID not provided.</td></tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Home Button -->
                        <a href="faculty_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
