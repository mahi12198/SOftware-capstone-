<?php
// Start the session to access session variables
session_start();

// Check if faculty is logged in
if (!isset($_SESSION['faculty_email'])) {
    // If not logged in, redirect to faculty login page
    header("Location: facultylogin.php");
    exit();
}

// Get faculty name from session
$faculty_name = $_SESSION['faculty_name'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Your Graduate Training Project - Faculty Dashboard</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
        }

        .dashboard-panel {
            margin-top: 110px;
            text-align: center;
        }
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
        <a class="navbar-brand text-white" href="index.php" style="padding-left: 45px;">
            <img src="images/umkc.png" alt="Logo" width="270" height="70">
        </a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white" href="add_job.php">Add Job</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="view_students.php">View Students</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="adminProfile.php">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Faculty Dashboard Panel -->
    <div class="container dashboard-panel">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Welcome, <?php echo $faculty_name; ?>!</h4>
                        <p class="card-text">You are now logged in to your faculty dashboard.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
