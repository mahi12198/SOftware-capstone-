<?php
// Start the session to access session variables
session_start();
// Include the database connection file
include("db_connect.php");
// Fetch data from the database
$query = "SELECT * FROM jobs";
$result = mysqli_query($connection, $query);
// Store the fetched data in an array
$jobs = [];
while ($row = mysqli_fetch_assoc($result)) {
  $jobs[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Your Graduate Training Project</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Custom styles -->
  <style>
    body {
      min-height: 100vh;
      display: flex;
      margin: 0;
      flex-direction: column;
      padding-top: 39px;
    }

    main {
      flex: 1;
    }

    footer {
      margin-top: auto;
    }

    .custom-container {
      padding-left: 80px;
      padding-top: 80px;
      width: 80%;
      /* Add any other styles as needed */
    }

    .card {
      margin-bottom: 1.5rem;
      box-shadow: 0 1px 15px 1px rgba(52, 40, 104, .08);
    }

    .card {
      background-clip: border-box;
      border: 1px solid rgb(11, 11, 11);
      border-radius: 28px;
    }

    .card-job {
      display: none;
    }
  </style>
</head>

<body>
  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top" style="filter: brightness(90%);">
    <a class="navbar-brand text-white" href="index.php" style="padding-left: 45px;">
      <img src="images/umkc.png" alt="Logo" width="270" height="70">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link text-white" href="login.php">Student Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="facultylogin.php">Admin Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="contact.php">Contact</a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="container-fluid">
    <div class="row">
      <!-- Filtering Job Section -->
      <div class="col-md-1">
        <nav class="container-fluid mt-0 custom-container" style="padding-left: 80px; padding-top: 80px;">
          <h1 class="text-dark mt-5">Filter Menu</h1>
          <div class="main" style="width: 240px;">
            <div class="row">
              <div class="col-lg-12 col-md-7 mt-5">
                <div class="card sidebars bg-light" style="filter: brightness(90%);">
                  <div class="card-body position-relative">
                    <a class="text-dark font-weight-bold" style="font-size: 20px;">Filter By:</a><br>
                    <a class="text-success-emphasis" style="font-size: 15px;">Choose Term:</a>
                    <div class="form-check form-switch text-dark">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
                      <label class="form-check-label mx-3" for="flexSwitchCheckChecked">Spring 2023</label>
                    </div>
                    <div class="form-check form-switch text-dark">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckTermFall">
                      <label class="form-check-label mx-3" for="flexSwitchCheckChecked">Fall 2023</label>
                    </div>
                    <a class="text-success-emphasis" style="font-size: 15px;">Current Level:</a>
                    <div class="form-check form-switch text-dark">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckLevel">
                      <label class="form-check-label mx-3" for="flexSwitchCheckChecked">Undergraduate</label>
                    </div>
                    <div class="form-check form-switch text-dark">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckGraduate">
                      <label class="form-check-label mx-3" for="flexSwitchCheckChecked">Graduate</label>
                    </div>
                    <a class="text-success-emphasis" style="font-size: 15px;">Position Applying For:</a>
                    <div class="form-check form-switch text-dark">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckPositionGrader">
                      <label class="form-check-label mx-3" for="flexSwitchCheckChecked">Grader</label>
                    </div>
                    <div class="form-check form-switch text-dark">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckPositionLabInstructor">
                      <label class="form-check-label mx-3" for="flexSwitchCheckChecked">Lab Instructor</label>
                    </div>
                    <a class="text-success-emphasis" style="font-size: 15px;">Current Major:</a>
                    <div class="form-check form-switch text-dark">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckMajorCS">
                      <label class="form-check-label mx-3" for="flexSwitchCheckChecked">CS</label>
                    </div>
                    <div class="form-check form-switch text-dark">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckMajorIT">
                      <label class="form-check-label mx-3" for="flexSwitchCheckChecked">IT</label>
                    </div>
                    <div class="form-check form-switch text-dark">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckMajorECE">
                      <label class="form-check-label mx-3" for="flexSwitchCheckChecked">ECE</label>
                    </div>
                    <div class="form-check form-switch text-dark">
                      <input class="form-check-input" type="checkbox" id="flexSwitchCheckMajorEE">
                      <label class="form-check-label mx-3" for="flexSwitchCheckChecked">EE</label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </nav>
      </div>
      <!-- Job Categories Section -->
      <div class="col-lg-11 col-md-8">
        <div class="container mt-4" style="padding-right: 130px; padding-top: 80px;">
          <div class="card-body">
            <h5 class="card-title text-dark text-upper mb-5" style="font-size: 39px;">Job Categories</h5>
            <div class="row">
              <?php foreach ($jobs as $job): ?>
                <div class="col-md-3"><!-- Job Categories Section -->

                  <div class="card card-job" data-term="<?php echo $job['graduation']; ?>"
                    data-level="<?php echo $job['skillrequired']; ?>" data-position="<?php echo $job['company']; ?>"
                    data-major="<?php echo $job['place']; ?>">
                    <div class="card-body">
                      <h5 class="card-title text-dark">
                        <?php echo $job['jobtitle']; ?>
                      </h5>
                      <div>
                        <span class="ml-5">Term:</span>
                        <span class="ml-4">
                          <?php echo $job['term']; ?>
                        </span><br>
                        <span class="ml-5">Level:</span>
                        <span class="ml-3">
                          <?php echo $job['level']; ?>
                        </span><br>
                        <span class="ml-5">Position:</span>
                        <span class="ml-4">
                          <?php echo $job['position']; ?>
                        </span><br>
                        <span class="ml-5">Major:</span>
                        <span class="ml-4">
                          <?php echo $job['major']; ?>
                        </span>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-outline-primary btn-sm view-job-btn" data-toggle="modal"
                          data-target="#jobModal" data-term="<?php echo $job['term']; ?>"
                          data-level="<?php echo $job['level']; ?>" data-position="<?php echo $job['position']; ?>"
                          data-major="<?php echo $job['major']; ?>">
                          View Job
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS and dependencies -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery=3.6.4.min.js"></script>
  <script>
    $(document).ready(function () {
      // Initialize the filter object
      var filters = {
        term: [],
        level: [],
        position: [],
        major: []
      };
      // Output PHP data to JavaScript
      var jobs = <?php echo json_encode($jobs); ?>;
      // Function to dynamically create card-job elements
      function createCardJob(job) {
        var cardJob = $('<div class="card card-job"></div>').data(job);
        cardJob.append('<div class="card-body"><h5 class="card-title text-dark">' + job.major + '</h5><div><span class="ml-5">Term:</span><span class="ml-4">' + job.term + '</span><br><span class="ml-5">Level:</span><span class="ml-3">' + job.level + '</span><span class="ml-5">Position:</span><span class="ml-4">' + job.position + '</span></div></div>');
        return cardJob;
      }
      // Function to append card-job elements to the DOM
      function appendCardJobs() {
        var container = $('.container'); // Change this selector to match your actual container
        container.empty(); // Clear existing content

        jobs.forEach(function (job) {
          var cardJob = createCardJob(job);
          container.append(cardJob);
        });
      }
      // Event Listener for checkbox change
      $('input[type="checkbox"]').on('change', function () {
        updateFilters();
        filterJobs();
      });
      // Function to update filters based on checked checkboxes
      function updateFilters() {
        filters.term = [];
        filters.level = [];
        filters.position = [];
        filters.major = [];
        // Update filters based on checked checkboxes
        if ($('#flexSwitchCheckDefault').prop('checked')) filters.term.push('Spring 2023');
        if ($('#flexSwitchCheckTermFall').prop('checked')) filters.term.push('Fall 2023');
        if ($('#flexSwitchCheckLevel').prop('checked')) filters.level.push('Undergraduate');
        if ($('#flexSwitchCheckGraduate').prop('checked')) filters.level.push('Graduate');
        if ($('#flexSwitchCheckPositionGrader').prop('checked')) filters.position.push('Grader');
        if ($('#flexSwitchCheckPositionLabInstructor').prop('checked')) filters.position.push('Lab Instructor');
        if ($('#flexSwitchCheckMajorCS').prop('checked')) filters.major.push('CS');
        if ($('#flexSwitchCheckMajorIT').prop('checked')) filters.major.push('IT');
        if ($('#flexSwitchCheckMajorECE').prop('checked')) filters.major.push('ECE');
        if ($('#flexSwitchCheckMajorEE').prop('checked')) filters.major.push('EE');
      }
      // Function to filter jobs based on the selected filters
      function filterJobs() {
        $('.card-job').hide();
        $('.card-job').filter(function () {
          var card = $(this).data();
          return (filters.term.length === 0 || filters.term.includes(card.term)) &&
            (filters.level.length === 0 || filters.level.includes(card.level)) &&
            (filters.position.length === 0 || filters.position.includes(card.position)) &&
            (filters.major.length === 0 || filters.major.every(major => card.major.includes(major)));
        }).show();
      }
      // Initial Filter
      filterJobs();

      // Event Listener for "View Job" button click
      $('.view-job-btn').on('click', function () {
        // Get job details from the button's data attributes
        var term = $(this).data('term');
        var level = $(this).data('level');
        var position = $(this).data('position');
        var major = $(this).data('major');

        // Use AJAX to fetch job details from the server
        $.ajax({
          url: 'get_job_details.php',
          method: 'POST',
          data: {
            term: term,
            level: level,
            position: position,
            major: major
          },
          dataType: 'json', // Expect JSON response
          success: function (response) {
            // Display job details in the modal
            $('#jobDetails').html(
              '<h5 class="card-title text-dark">' + response.jobtitle + '</h5>' +
              '<div><span class="ml-5">Term:</span><span class="ml-4">' + response.term + '</span><br>' +
              '<span class="ml-5">Level:</span><span class="ml-3">' + response.level + '</span><br>' +
              '<span class="ml-5">Position:</span><span class="ml-4">' + response.position + '</span><br>' +
              '<span class="ml-5">Major:</span><span class="ml-4">' + response.major + '</span></div>'
            );
          },
          error: function (xhr, status, error) {
            console.error(xhr.responseText);
          }
        });
      });
    });
  </script>
  <!-- Modal -->
  <div class="modal fade" id="jobModal" tabindex="-1" role="dialog" aria-labelledby="jobModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <?php foreach ($jobs as $job): ?>
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title text-dark" id="jobModalLabel">
              <?php echo $job['jobtitle']; ?>
            </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <!-- Display job details here -->
            <form id="add-product-form">
              <div class="row">
                <div class="col-6"><!-- start 1 -->
                  <div class="form-group">
                    <div>
                      <span class="ml-2 text-dark font-weight-bold">Term:</span>
                      <span class="ml-4 text-dark">
                        <?php echo $job['term']; ?>
                      </span><br>
                    </div>
                  </div>
                </div>
                <div class="col-6"><!-- start 2 -->
                  <div class="form-group">
                    <div>
                      <span class="ml-2 text-dark font-weight-bold">Level:</span>
                      <span class="ml-4 text-dark">
                        <?php echo $job['level']; ?>
                      </span><br>
                    </div>
                  </div>
                </div>
                <div class="col-6"><!-- start 3 -->
                  <div class="form-group">
                    <div>
                      <span class="ml-2 text-dark font-weight-bold">Position:</span>
                      <span class="ml-4 text-dark">
                        <?php echo $job['position']; ?>
                      </span><br>
                    </div>
                  </div>
                </div>
                <div class="col-6"><!-- start 4 -->
                  <div class="form-group">
                    <div>
                      <span class="ml-2 text-dark font-weight-bold">Department:</span>
                      <span class="ml-4 text-dark">
                        <?php echo $job['major']; ?>
                      </span><br>
                    </div>
                  </div>
                </div>
                <div class="col-6"><!-- start 5 -->
                  <div class="form-group">
                    <div>
                      <span class="ml-2 text-dark font-weight-bold">Contact Detail:</span>
                      <span class="ml-4 text-dark">
                        <?php echo $job['contact_details']; ?>
                      </span><br>
                    </div>
                  </div>
                </div>
                <div class="col-6"><!-- start 6 -->
                  <div class="form-group">
                    <div>
                      <span class="ml-2 text-dark font-weight-bold">Company:</span>
                      <span class="ml-4 text-dark">
                        <?php echo $job['company']; ?>
                      </span><br>
                    </div>
                  </div>
                </div>
                <div class="col-6"><!-- start 7 -->
                  <div class="form-group">
                    <div>
                      <span class="ml-2 text-dark font-weight-bold">Skill Required:</span>
                      <span class="ml-4 text-dark">
                        <?php echo $job['skillrequired']; ?>
                      </span><br>
                    </div>
                  </div>
                </div>
                <div class="col-12"><!-- start 8 -->
                  <div class="form-group">
                    <div>
                      <span class="ml-2 text-dark font-weight-bold">Job Description:</span><br>
                      <span class="ml-4 text-dark">
                        <?php echo $job['profile']; ?>
                      </span><br>
                    </div>
                  </div>
                </div>
              </div>
            </form>
            <div id="jobDetails"></div>
          </div>
          <div class="modal-footer">
            <a href="login.php" class="btn btn-outline-primary">Apply</a>
            <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <!-- Footer Section -->
  <footer class="text-center text-lg-start bg-primary" style="filter: brightness(90%);">
    <section class="d-flex justify-content-center justify-content-lg-around p-0 border-bottom">
      <div class="container text-md-start mt-0">
        <div class="row mt-0">
          <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mb-4 text-center">
            <a class="navbar-brand text-light" href="index.php">
              <img src="images/umkc.png" alt="Logo" width="300" height="120">
            </a>
          </div>
          <div class="col-lg-4 col-xl-6"></div>
          <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
            <h6 class="text-uppercase fw-bold mb-3 mt-3 text-white" style="font-size: 30px;">Contact US:</h6>
            <p class="text-white mb-0" style="font-size: 20px;">
              <i class="fa fa-envelope me-3 text-white"></i>
              umkcsgs@umkc.edu
            </p>
            <p class="text-white" style="font-size: 20px;"><i class="fa fa-phone me-3 text-white"></i> 816-235-1301</p>
          </div>
        </div>
      </div>
    </section>
    <!-- Copyright -->
    <div class="text-center p-2 text-white" style="background-color: rgba(0, 0, 0, 0.025);">copy; copyright @2023 by
      <span>mr. web designer</span> all right reserved!
    </div>
  </footer>
</body>

</html>