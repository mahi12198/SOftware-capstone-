<?php
// Start the session to access session variables
session_start();

// Include the database connection file
include("db_connect.php");

// Check if the user is logged in
if (!isset($_SESSION['student_id'])) {
    // If not logged in, redirect to the login page
    header("Location: login.php");
    exit();
}

// Check if the job ID is provided in the URL
if (!isset($_GET['job_id'])) {
    // If not provided, redirect to the applied jobs page
    header("Location: appliedJobs.php");
    exit();
}

// Sanitize and retrieve the job ID from the URL
$jobId = mysqli_real_escape_string($connection, $_GET['job_id']);

// Sanitize and retrieve the student ID from the session
$studentId = mysqli_real_escape_string($connection, $_SESSION['student_id']);

// Check if the job application exists
$checkApplicationQuery = "SELECT * FROM job_applications WHERE job_id = $jobId AND student_id = $studentId";
$checkApplicationResult = mysqli_query($connection, $checkApplicationQuery);

if (!$checkApplicationResult || mysqli_num_rows($checkApplicationResult) == 0) {
    // If the application does not exist, redirect to the applied jobs page
    header("Location: appliedJobs.php");
    exit();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Delete the job application from the database
    $deleteApplicationQuery = "DELETE FROM job_applications WHERE job_id = $jobId AND student_id = $studentId";

    if (mysqli_query($connection, $deleteApplicationQuery)) {
        // If the deletion is successful, redirect to a success page
        header("Location: cancelSuccess.php");
        exit();
    } else {
        // If the deletion fails, redirect to an error page
        header("Location: cancelError.php");
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Your Graduate Training Project - Cancel Application</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
        }

        .cancel-application-panel {
            margin-top: 100px;
        }
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-info fixed-top">
        <a class="navbar-brand text-white" href="student_dashboard.php">UMKC - GTA</a>
    </nav>

    <!-- Cancel Application Panel -->
    <div class="container cancel-application-panel">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center">Cancel Application</h4>
                        <p class="card-text">Are you sure you want to cancel your application for this job?</p>

                        <!-- Confirm Form -->
                        <form action="" method="post">
                            <button type="submit" class="btn btn-danger">Cancel Application</button>
                            <a href="appliedJobs.php" class="btn btn-secondary">Back to Applied Jobs</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
