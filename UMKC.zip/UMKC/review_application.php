<?php
session_start();

// Check if faculty is logged in
if (!isset($_SESSION['faculty_email'])) {
    header("Location: facultylogin.php");
    exit();
}

// Include the database connection file
include("db_connect.php");

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['application_id'])) {
    $applicationId = mysqli_real_escape_string($connection, $_GET['application_id']);

    // Update the status to reviewed
    $updateStatusQuery = "UPDATE job_applications SET status = 1 WHERE id = $applicationId";
    
    if (mysqli_query($connection, $updateStatusQuery)) {
        // Redirect back to the faculty dashboard
        header("Location: faculty_dashboard.php");
        exit();
    } else {
        // Handle the error, if any
        echo "Error updating status: " . mysqli_error($connection);
    }
} else {
    // Redirect to the faculty dashboard if no valid application_id is provided
    header("Location: faculty_dashboard.php");
    exit();
}
?>
