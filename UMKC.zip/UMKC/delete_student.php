<?php
// Include the database connection file
include("db_connect.php");

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    // Sanitize and retrieve the student ID from the URL
    $studentId = mysqli_real_escape_string($connection, $_GET['id']);

    // SQL query to delete the student with the specified ID
    $sql = "DELETE FROM regstudent WHERE id = $studentId";

    // Execute the query
    if (mysqli_query($connection, $sql)) {
        // If deletion is successful, redirect to view_students.php
        header("Location: view_students.php");
        exit();
    } else {
        // If deletion fails, redirect to an error page
        header("Location: error_delete_student.php");
        exit();
    }
} else {
    // If 'id' parameter is not set in the URL, redirect to an error page
    header("Location: error_delete_student.php");
    exit();
}
?>
