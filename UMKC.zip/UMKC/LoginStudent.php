<?php
// Include the database connection file
include("db_connect.php");
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Example SQL query to check student credentials
    $sql = "SELECT * FROM regstudent WHERE mailid = '$email' AND password = '$password'";
    $result = mysqli_query($connection, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        // Login successful
        $row = mysqli_fetch_assoc($result);

        // Store user data in session
        $_SESSION['student_id'] = $row['id'];
        $_SESSION['student_name'] = $row['name'];
        $_SESSION['student_lastname'] = $row['lastname'];
        $_SESSION['student_email'] = $row['mailid'];
        $_SESSION['student_grad_level'] = $row['graduation_level'];
        $_SESSION['student_major'] = $row['major'];
        $_SESSION['student_dob'] = $row['date_of_birth'];
        $_SESSION['student_international'] = $row['IntStudent'];
        $_SESSION['student_toefl_score'] = $row['toefl_score'];
        $_SESSION['student_grad_asst_score'] = $row['grad_asst_score'];
        $_SESSION['student_phone'] = $row['phone'];

        // Redirect to student dashboard
        header("Location: student_dashboard.php");
        exit();
    } else {
        // Login failed
        header("Location: loginStdFail.php");
        exit();
    }
} else {
    // Redirect to an error page if accessed without submitting the form
    header("Location: loginStdFail.php");
    exit();
}
?>
