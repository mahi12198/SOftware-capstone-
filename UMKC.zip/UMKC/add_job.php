<?php
// Start the session to access session variables
session_start();

// Check if faculty is logged in
if (!isset($_SESSION['faculty_email'])) {
    // If not logged in, redirect to faculty login page
    header("Location: facultylogin.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Your Graduate Training Project - Add Job</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
        }

        .add-job-panel {
            margin-top: 110px;
        }
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
        <a class="navbar-brand text-white" href="index.php" style="padding-left: 45px;">
            <img src="images/umkc.png" alt="Logo" width="270" height="70">
        </a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white" href="add_job.php">Add Job</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="view_students.php">View Students</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="adminProfile.php">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Add Job Panel -->
    <div class="container add-job-panel">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center">Add Job</h4>

                        <!-- Add Job Form -->
                        <form action="AddJobDB.php" method="post">
                            <div class="form-group">
                                <label for="jobtitle">Job Title:</label>
                                <input type="text" class="form-control" id="jobtitle" name="jobtitle" required>
                            </div>
                            <div class="form-group">
                                <label for="graduation">Graduation Level:</label>
                                <input type="text" class="form-control" id="graduation" name="graduation" required>
                            </div>
                            <div class="form-group">
                                <label for="skillrequired">Skills Required:</label>
                                <input type="text" class="form-control" id="skillrequired" name="skillrequired" required>
                            </div>
                            <div class="form-group">
                                <label for="graduateStd">Graduate Students Eligible:</label>
                                <select class="form-control" id="graduateStd" name="graduateStd" required>
                                    <option value="1">Yes</option>
                                    <option value="0">No</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="contact_details">Contact Details:</label>
                                <input type="text" class="form-control" id="contact_details" name="contact_details" required>
                            </div>
                            <div class="form-group">
                                <label for="profile">Job Profile:</label>
                                <textarea class="form-control" id="profile" name="profile" rows="4" required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="company">Company:</label>
                                <input type="text" class="form-control" id="company" name="company" required>
                            </div>
                            <div class="form-group">
                                <label for="place">Location:</label>
                                <input type="text" class="form-control" id="place" name="place" required>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Add Job</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
