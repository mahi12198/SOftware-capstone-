<?php
// Start the session to access session variables
session_start();

// Include the database connection file
include("db_connect.php");

// Check if the user is logged in
if (!isset($_SESSION['student_id'])) {
    // If not logged in, redirect to the login page
    header("Location: login.php");
    exit();
}

// Check if the job ID is provided in the URL
if (!isset($_GET['job_id'])) {
    // If not provided, redirect to the search jobs page
    header("Location: searchJob.php");
    exit();
}

// Sanitize and retrieve the job ID from the URL
$jobId = mysqli_real_escape_string($connection, $_GET['job_id']);

// Sanitize and retrieve the student ID from the session
$studentId = mysqli_real_escape_string($connection, $_SESSION['student_id']);

// Check if the job exists in the database
$checkJobQuery = "SELECT * FROM jobs WHERE id = $jobId";
$checkJobResult = mysqli_query($connection, $checkJobQuery);

if (!$checkJobResult || mysqli_num_rows($checkJobResult) == 0) {
    // If the job does not exist, redirect to the search jobs page
    header("Location: searchJob.php");
    exit();
}

// Check if the job application already exists
$checkApplicationQuery = "SELECT * FROM job_applications WHERE job_id = $jobId AND student_id = $studentId";
$checkApplicationResult = mysqli_query($connection, $checkApplicationQuery);

if ($checkApplicationResult && mysqli_num_rows($checkApplicationResult) > 0) {
    // If the application already exists, redirect to a page indicating that the application has already been submitted
    header("Location: alreadyApplied.php");
    exit();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and retrieve personal information from the form
    $personalInfo = mysqli_real_escape_string($connection, $_POST['personal_info']);

    // Get the current date for the application
    $applyDate = date("Y-m-d");

    // Insert the job application into the database
    $insertApplicationQuery = "INSERT INTO job_applications (job_id, student_id, apply_date, personal_info) 
                              VALUES ($jobId, $studentId, '$applyDate', '$personalInfo')";

    if (mysqli_query($connection, $insertApplicationQuery)) {
        // If the application is successful, redirect to a success page
        header("Location: applicationSuccess.php");
        exit();
    } else {
        // If the application fails, redirect to an error page
        header("Location: applicationError.php");
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Your Graduate Training Project - Apply for Job</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
        }

        .apply-job-panel {
            margin-top: 100px;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
            <a class="navbar-brand text-white" href="index.php" style="padding-left: 45px;">
                <img src="images/umkc.png" alt="Logo" width="270" height="70">
            </a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="applyJob.php">Job Apply</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="searchJob.php">Search Job</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="appliedJobs.php">Applied Job</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="studentProfile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </nav>

    <!-- Apply for Job Panel -->
    <div class="container apply-job-panel">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center">Apply for Job</h4>

                        <!-- Job Information -->
                        <?php
                        $jobInfoQuery = "SELECT * FROM jobs WHERE id = $jobId";
                        $jobInfoResult = mysqli_query($connection, $jobInfoQuery);

                        if ($jobInfoResult && $jobInfoRow = mysqli_fetch_assoc($jobInfoResult)) {
                            echo '<p><strong>Job Title:</strong> ' . $jobInfoRow['jobtitle'] . '</p>';
                            echo '<p><strong>Graduation:</strong> ' . $jobInfoRow['graduation'] . '</p>';
                            echo '<p><strong>Skill Required:</strong> ' . $jobInfoRow['skillrequired'] . '</p>';
                            echo '<p><strong>Graduate Students:</strong> ' . $jobInfoRow['graduateStd'] . '</p>';
                            echo '<p><strong>Contact Details:</strong> ' . $jobInfoRow['contact_details'] . '</p>';
                            echo '<p><strong>Profile:</strong> ' . $jobInfoRow['profile'] . '</p>';
                            echo '<p><strong>Company:</strong> ' . $jobInfoRow['company'] . '</p>';
                            echo '<p><strong>Place:</strong> ' . $jobInfoRow['place'] . '</p>';
                        }
                        ?>

                        <!-- Application Form -->
                        <form action="" method="post" class="mt-3">
                            <div class="form-group">
                                <label for="personalInfo">Personal Information:</label>
                                <textarea class="form-control" id="personalInfo" name="personal_info" rows="4" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Apply</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
