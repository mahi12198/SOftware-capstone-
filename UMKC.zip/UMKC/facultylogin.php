<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Your Graduate Training Project - Faculty Login</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
            display: flex;
            margin: 0;
            flex-direction: column;
            padding-top: 39px;
        }
        footer {
      margin-top: auto;
    }

        .login-panel {
            margin-top: 100px;
        }
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
    <a class="navbar-brand text-white" href="index.php" style="padding-left: 45px;">
      <img src="images/umkc.png" alt="Logo" width="270" height="70">
    </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white" href="login.php">Student Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="facultylogin.php">Admin Login</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link text-white" href="contact.php">Contact</a>
                </li>
            </ul>
        </div>
    </nav>

	
    <!-- Login Panel for Faculty -->
    <div class="container login-panel">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center">Faculty Login</h4>

                        <!-- Faculty Login Form -->
                        <form action="LoginFaculty.php" method="post">
                            <div class="form-group">
                                <label for="faculty_email">Email:</label>
                                <input type="email" class="form-control" id="faculty_email" name="faculty_email" required>
                            </div>
                            <div class="form-group">
                                <label for="faculty_password">Password:</label>
                                <input type="password" class="form-control" id="faculty_password" name="faculty_password" required>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Login</button>
                        </form>

                        <!-- Register Link -->
                        <div class="mt-3 text-center">
                            <p>Don't have an account? <a href="facultyregister.php">Register</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <footer class="text-center text-lg-start bg-primary" style="filter: brightness(90%);">
    <section class="d-flex justify-content-center justify-content-lg-around p-0 border-bottom">
      <div class="container text-md-start mt-0">
        <div class="row mt-0">
          <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mb-4 text-center">
            <a class="navbar-brand text-light" href="index.php">
              <img src="images/umkc.png" alt="Logo" width="300" height="120">
            </a>
          </div>
          <div class="col-lg-4 col-xl-6"></div>
          <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
            <h6 class="text-uppercase fw-bold mb-3 mt-3 text-white" style="font-size: 30px;">Contact US:</h6>
            <p class="text-white mb-0" style="font-size: 20px;">
              <i class="fa fa-envelope me-3 text-white"></i>
              umkcsgs@umkc.edu
            </p>
            <p class="text-white" style="font-size: 20px;"><i class="fa fa-phone me-3 text-white"></i> 816-235-1301</p>
          </div>
        </div>
      </div>
    </section>
    <!-- Copyright -->
    <div class="text-center p-2 text-white" style="background-color: rgba(0, 0, 0, 0.025);">copy; copyright @2023 by
      <span>mr. web designer</span> all right reserved!
    </div>
  </footer>

</body>

</html>
