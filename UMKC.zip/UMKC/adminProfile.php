<?php
// Start the session to access session variables
session_start();
// Include the database connection file
include("db_connect.php");
// Fetch student data from the database
$facultyId = $_SESSION['faculty_id']; // Assuming you store student ID in the session
$query = "SELECT * FROM faculty WHERE faculty_id = $facultyId";
$result = mysqli_query($connection, $query);
// Check for errors in the query
if (!$result) {
    die("Query failed: " . mysqli_error($connection));
}
// Check if any rows were returned
if (mysqli_num_rows($result) == 0) {
    die("No data found for faculty_id: $facultyId");
}
// Store the fetched data in an array
$userData = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Graduate Training Project- Profile Page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
            display: flex;
            margin: 0;
            flex-direction: column;
            padding-top: 39px;
        }
        .register-panel {
            margin-top: 100px;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
        <a class="navbar-brand text-white" href="index.php" style="padding-left: 45px;">
            <img src="images/umkc.png" alt="Logo" width="270" height="70">
        </a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white" href="applyJob.php">Job Apply</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="searchJob.php">Search Job</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="appliedJobs.php">Applied Job</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="adminProfile.php">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    <!-- Content of the profile page  -->
    <div class="container register-panel">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center text-dark">Admin Profile</h4>

                        <!-- Faculty Registration Form -->
                        <form action="updateAdminProfile.php" method="post">
                            <div class="form-group">
                                <label for="labels">Name:</label>
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo $userData['name']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="labels">Email:</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo $userData['email']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="labels">Department:</label>
                                <input type="text" class="form-control" id="department" name="department" value="<?php echo $userData['department']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="labels">Phone:</label>
                                <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo $userData['phone']; ?>">
                            </div>
                            <button type="submit" class="btn btn-outline-primary btn-md">Register</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>