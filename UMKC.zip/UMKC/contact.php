<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Your Graduate Training Project</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="side.css">
    <!-- Custom styles -->
    <style>
	body {
        /* padding-top: 56px; Adjust the top padding to accommodate the fixed navbar
         background-image: url('images/bg.jpeg');
        background-color: rgba(255, 255, 255, 0.1);
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment: fixed; Ensures the background image stays fixed as the page is scrolled
        background-position: center center; */
        min-height: 100vh;
        display: flex;
        margin: 0;
        flex-direction: column;
        padding-top: 39px; /*Adjust the top padding to accommodate the fixed navbar*/
        }
        main{
            flex: 1;
        }
        footer{
            margin-top: auto;
        }
    </style>
</head>

<body >

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top" style="filter: brightness(90%);">
        <a class="navbar-brand text-white" href="index.php" style="padding-left: 45px;">
            <img src="images/umkc.png" alt="Logo" width="270" height="70">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white" href="login.php">Student Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="facultylogin.php">Admin Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="contact.php">Contact</a>
                </li>
            </ul>
        </div>
    </nav>
    <section class="mb-5 mt-5">

    <!--Section heading-->
    <h2 class="h1-responsive font-weight-bold text-center my-4">Contact us</h2>
    <!--Section description-->
    <p class="text-center w-responsive mx-auto mb-5">Do you have any questions? Please do not hesitate to contact us directly. Our team will come back to you within
        a matter of hours to help you.</p>

    <div class="row">

        <!--Grid column-->
        <div class="col-md-2 mb-md-0 mb-5"></div>
        <div class="col-md-5 mb-md-0 mb-5">
            <form id="contact-form" name="contact-form" action="mail.php" method="POST">

                <!--Grid row-->
                <div class="row">

                    <!--Grid column-->
                    <div class="col-md-6">
                        <div class="md-form mb-0">
                            <input type="text" id="name" name="name" class="form-control form-control-lg">
                            <label for="name" class="">Your name</label>
                        </div>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-md-6">
                        <div class="md-form mb-0">
                            <input type="text" id="email" name="email" class="form-control">
                            <label for="email" class="">Your email</label>
                        </div>
                    </div>
                    <!--Grid column-->

                </div>
                <!--Grid row-->

                <!--Grid row-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="md-form mb-0">
                            <input type="text" id="subject" name="subject" class="form-control">
                            <label for="subject" class="">Subject</label>
                        </div>
                    </div>
                </div>
                <!--Grid row-->

                <!--Grid row-->
                <div class="row">

                    <!--Grid column-->
                    <div class="col-md-12">

                        <div class="md-form">
                            <textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea"></textarea>
                            <label for="message">Your message</label>
                        </div>

                    </div>
                </div>
                <!--Grid row-->

            </form>

            <div class="text-center text-md-left">
                <a class="btn btn-primary" onclick="document.getElementById('contact-form').submit();">Send</a>
            </div>
            <div class="status"></div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-3 text-center">
            <ul class="list-unstyled mb-0">
                <li><i class="fa fa-map-marker fa-2x"></i>
                    <p>Kansas City, MO, 64110 USA</p>
                </li>

                <li><i class="fa fa-phone mt-4 fa-2x"></i>
                    <p>816-235-1301</p>
                </li>

                <li><i class="fa fa-envelope mt-4 fa-2x"></i>
                    <p>umkcsgs@umkc.edu</p>
                </li>
            </ul>
        </div>
        <!--Grid column-->

    </div>

</section>
    
    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
<footer class="text-center text-lg-start bg-primary" style="filter: brightness(90%);">
  <!-- Section: Links  -->
  <section class="d-flex justify-content-center justify-content-lg-around p-0 border-bottom">
    <div class="container text-md-start mt-0">
      <!-- Grid row -->
      <div class="row mt-0">
        <!-- Grid column -->
        <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mb-4 text-center">
          <!-- Content -->
          <a class="navbar-brand text-light" href="index.php">
            <img src="images/umkc.png" alt="Logo" width="300" height="120">
          </a>
        </div>
        <div class="col-lg-4 col-xl-6"></div>
        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-3 mt-3 text-white" style="font-size: 30px;">Contact US:</h6>
          <p class="text-white mb-0" style="font-size: 20px;">
            <i class="fa fa-envelope me-3 text-white"></i>
            umkcsgs@umkc.edu
          </p>
          <p class="text-white" style="font-size: 20px;"><i class="fa fa-phone me-3 text-white"></i> 816-235-1301</p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <!-- <div class="col-md-3 col-lg-4 col-xl-3 mx-auto text-center">
        <h6 class="text-uppercase fw-bold mt-5 text-white" style="font-size: 35px;">
            <i class="fa fa-gem me-3 text-secondary"></i>University Of Missouri Kansas City
          </h6>
        </div> -->
      </div>
    </div>
  </section>
  <!-- Copyright -->
  <div class="text-center p-2 text-white" style="background-color: rgba(0, 0, 0, 0.025);">copy; copyright @2023 by <span>mr. web designer</span> all right reserved!
  </div>
</footer>
</html>
