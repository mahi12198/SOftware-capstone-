<?php
// Start the session to access session variables
session_start();

// Check if faculty is logged in
if (!isset($_SESSION['faculty_email'])) {
    // If not logged in, redirect to faculty login page
    header("Location: facultylogin.php");
    exit();
}

// Include the database connection file
include("db_connect.php");

// Function to display students based on search criteria
function displayStudents($connection, $searchCriteria)
{
    $sql = "SELECT * FROM regstudent 
            WHERE name LIKE '%$searchCriteria%' OR lastname LIKE '%$searchCriteria%' 
                OR mailid LIKE '%$searchCriteria%' OR graduation_level LIKE '%$searchCriteria%'
                OR major LIKE '%$searchCriteria%' OR date_of_birth LIKE '%$searchCriteria%'
                OR IntStudent LIKE '%$searchCriteria%' OR toefl_score LIKE '%$searchCriteria%'
                OR grad_asst_score LIKE '%$searchCriteria%' OR phone LIKE '%$searchCriteria%'";

    $result = mysqli_query($connection, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<tr>';
            echo '<td>' . $row['name'] . '</td>';
            echo '<td>' . $row['lastname'] . '</td>';
            echo '<td>' . $row['mailid'] . '</td>';
            echo '<td>' . $row['graduation_level'] . '</td>';
            echo '<td>' . $row['major'] . '</td>';
            echo '<td>' . $row['date_of_birth'] . '</td>';
            echo '<td>' . ($row['IntStudent'] ? 'Yes' : 'No') . '</td>';
            echo '<td>' . $row['toefl_score'] . '</td>';
            echo '<td>' . $row['grad_asst_score'] . '</td>';
            echo '<td>' . $row['phone'] . '</td>';
            echo '<td><a href="delete_student.php?id=' . $row['id'] . '" class="btn btn-danger btn-sm">Delete</a></td>';
            echo '<td><a href="appliedJobsStd.php?id=' . $row['id'] . '" class="btn btn-primary btn-sm">View Jobs Applied</a></td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="12" class="text-center">No students found.</td></tr>';
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Your Graduate Training Project - View Students</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
        }

        .view-students-panel {
            margin-top: 110px;
        }
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
        <a class="navbar-brand text-white" href="index.php" style="padding-left: 45px;">
            <img src="images/umkc.png" alt="Logo" width="270" height="70">
        </a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white" href="add_job.php">Add Job</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="view_students.php">View Students</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="adminProfile.php">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- View Students Panel -->
    <div class="container view-students-panel">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center">View Students</h4>

                        <!-- Search Form -->
                        <form action="" method="get" class="mb-3">
                            <div class="form-group">
                                <label for="searchCriteria">Search Criteria:</label>
                                <input type="text" class="form-control" id="searchCriteria" name="searchCriteria" placeholder="Enter any criteria">
                            </div>
                            <button type="submit" class="btn btn-outline-primary">Search</button>
                        </form>

                        <!-- Students Table -->
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Lastname</th>
                                        <th>Email</th>
                                        <th>Graduation Level</th>
                                        <th>Major</th>
                                        <th>Date of Birth</th>
                                        <th>International Student</th>
                                        <th>TOEFL Score</th>
                                        <th>Grad Assistant Score</th>
                                        <th>Phone</th>
                                        <th>Action</th>
                                        <th>View Jobs Applied</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Display students based on search criteria
                                    $searchCriteria = isset($_GET['searchCriteria']) ? $_GET['searchCriteria'] : '';
                                    displayStudents($connection, $searchCriteria);
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
