<?php
session_start();
include("db_connect.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Assuming faculty_id is stored in the session
    $facultyId = $_SESSION['faculty_id'];

    // Collect form data
    $name = mysqli_real_escape_string($connection, $_POST['name']);
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $department = mysqli_real_escape_string($connection, $_POST['department']);
    $phones = mysqli_real_escape_string($connection, $_POST['phone']);

    // Validate phone number (numeric, 10 digits)
    if (!preg_match("/^[0-9]{10}$/", $phones)) {
        echo "Invalid phone number format";
        exit();
    }

    // Update faculty data in the database using a prepared statement
    $query = "UPDATE faculty SET name=?, email=?, phone=? WHERE faculty_id=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "sssi", $name, $email, $phones, $facultyId);

    if (mysqli_stmt_execute($stmt)) {
        // Update successful, redirect to the profile page
        header("Location: faculty_dashboard.php");
        exit();
    } else {
        // Update failed, handle the error
        echo "Error updating profile: " . mysqli_error($connection);
    }

    mysqli_stmt_close($stmt);
}
?>
