<?php
// Include the database connection file
include("db_connect.php");
session_start();

// Check if faculty is logged in
if (!isset($_SESSION['faculty_email'])) {
    // If not logged in, redirect to faculty login page
    header("Location: facultylogin.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $jobtitle = $_POST['jobtitle'];
    $graduation = $_POST['graduation'];
    $skillrequired = $_POST['skillrequired'];
    $graduateStd = $_POST['graduateStd'];
    $contact_details = $_POST['contact_details'];
    $profile = $_POST['profile'];
    $company = $_POST['company'];
    $place = $_POST['place'];
    $term = $_POST['term'];
    $level = $_POST['level'];
    $position = $_POST['position'];
    $major = $_POST['major'];

    $sql = "INSERT INTO jobs (jobtitle, graduation, skillrequired, graduateStd, contact_details, profile, company, place, term, level, position, major) 
            VALUES ('$jobtitle', '$graduation', '$skillrequired', '$graduateStd', '$contact_details', '$profile', '$company', '$place', '$term', '$level', '$position', '$major')";

    if (mysqli_query($connection, $sql)) {
        echo '<script>alert("Registered successfully. You can now add a job.");</script>';

        header("Location: add_job.php");
        exit();
    } else {
        // Error in adding job, redirect to an error page
        header("Location: error_add_job.php");
        exit();
    }
} else {
    // Redirect to an error page if accessed without submitting the form
    header("Location: error_add_job.php");
    exit();
}
?>