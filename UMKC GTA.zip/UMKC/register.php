<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Your Graduate Training Project - Register</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
            display: flex;
            margin: 0;
            flex-direction: column;
            padding-top: 39px;
        }

        footer {
            margin-top: 20px;
        }

        .register-panel {
            margin-top: 100px;
        }
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
        <a class="navbar-brand text-white" href="index.php" style="padding-left: 45px;">
            <img src="images/umkc.png" alt="Logo" width="270" height="70">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="login.php">Student Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="facultylogin.php">Admin Login</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="contact.php">Contact</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Register Panel -->
    <div class="container register-panel">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center">Register</h4>

                        <!-- Add your registration form here -->
                        <form action="RegisterStudent.php" method="post">
                            <div class="form-group">
                                <label for="name">First Name:</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="form-group">
                                <label for="lastname">Last Name:</label>
                                <input type="text" class="form-control" id="lastname" name="lastname" required>
                            </div>
                            <div class="form-group">
                                <label for="mailid">Email:</label>
                                <input type="email" class="form-control" id="mailid" name="mailid" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="form-group">
                                <label for="graduation_level">Graduation Level:</label>
                                <select class="form-control" id="graduation_level" name="graduation_level" required>
                                    <option value="Undergraduate">Undergraduate</option>
                                    <option value="Graduate">Graduate</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="major">Major:</label>
                                <select class="form-control" id="major" name="major" required>
                                    <option value="Computer Science">Computer Science</option>
                                    <option value="Engineering">Engineering</option>
                                    <!-- Add more options as needed -->
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="date_of_birth">Date of Birth:</label>
                                <input type="date" class="form-control" id="date_of_birth" name="date_of_birth"
                                    required>
                            </div>
                            <div class="form-group">
                                <label for="IntStudent">International Student:</label>
                                <div class="form-check">
                                    <input type="radio" class="form-check-input" id="IntStudentYes" name="IntStudent"
                                        value="1" required>
                                    <label class="form-check-label" for="IntStudentYes">Yes</label>
                                </div>
                                <div class="form-check">
                                    <input type="radio" class="form-check-input" id="IntStudentNo" name="IntStudent"
                                        value="0" required>
                                    <label class="form-check-label" for="IntStudentNo">No</label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="toefl_score">TOEFL Score:</label>
                                <input type="number" class="form-control" id="toefl_score" name="toefl_score">
                            </div>
                            <div class="form-group">
                                <label for="grad_asst_score">Grad Assistant Score:</label>
                                <input type="number" class="form-control" id="grad_asst_score" name="grad_asst_score">
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone:</label>
                                <input type="tel" class="form-control" id="phone" name="phone" required>
                            </div>
                            <button type="submit" class="btn btn-outline-primary btn-block">Register</button>
                        </form>
                        <hr>

                        <p class="text-center text-dark">Alredy have an account? <a href="login.php"
                                class="text-primary">Login here</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <footer class="text-center text-lg-start bg-primary" style="filter: brightness(90%);">
        <section class="d-flex justify-content-center justify-content-lg-around p-0 border-bottom">
            <div class="container text-md-start mt-0">
                <div class="row mt-0">
                    <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mb-4 text-center">
                        <a class="navbar-brand text-light" href="index.php">
                            <img src="images/umkc.png" alt="Logo" width="300" height="120">
                        </a>
                    </div>
                    <div class="col-lg-4 col-xl-6"></div>
                    <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                        <h6 class="text-uppercase fw-bold mb-3 mt-3 text-white" style="font-size: 30px;">Contact US:
                        </h6>
                        <p class="text-white mb-0" style="font-size: 20px;">
                            <i class="fa fa-envelope me-3 text-white"></i>
                            umkcsgs@umkc.edu
                        </p>
                        <p class="text-white" style="font-size: 20px;"><i class="fa fa-phone me-3 text-white"></i>
                            816-235-1301</p>
                    </div>
                    <!-- <div class="col-md-2 col-lg-2 col-xl-3 mx-auto mb-4 text-light">
                     
                        <h6 class="text-uppercase fw-bold mb-4 text-light">
                            Social Networks
                        </h6>
                        <i class="fa fa-facebook-square link-secondart mr-5" style="font-size: 40px;"></i>
                        <i class="fa fa-twitter-square link-secondart mr-5" style="font-size: 40px;"></i>
                        <i class="fa fa-google-plus link-secondart mr-5" style="font-size: 40px;"></i>
                        <i class="fa fa-instagram link-secondart mr-5" style="font-size: 40px;"></i>
                        <i class="fa fa-linkedin-square link-secondart mr-5" style="font-size: 40px;"></i>
                        <i class="fa fa-github-square link-secondart mr-5" style="font-size: 40px;"></i>
                    </div> -->
                </div>
            </div>
        </section>

        <div class="text-center p-2 text-white" style="background-color: rgba(0, 0, 0, 0.025);">copy; copyright @2023 by
            <span>mr. web designer</span> all right reserved!
        </div>
    </footer>

</body>

</html>