<?php
// Start the session to access session variables
session_start();

// Include the database connection file
include("db_connect.php");

// Check if the user is logged in
if (!isset($_SESSION['student_id'])) {
    // If not logged in, redirect to the login page
    header("Location: login.php");
    exit();
}
// Check if student is logged in
if (!isset($_SESSION['student_email'])) {
    // If not logged in, redirect to login page
    header("Location: LoginStudent.php");
    exit();
}

// Get student name from session
$student_name = $_SESSION['student_name'];


// Sanitize and retrieve the student ID from the session
$studentId = mysqli_real_escape_string($connection, $_SESSION['student_id']);

// Fetch applied jobs data from the database
$appliedJobsQuery = "SELECT jobs.*, job_applications.apply_date, job_applications.resume, job_applications.status
                    FROM jobs
                    JOIN job_applications ON jobs.id = job_applications.job_id
                    JOIN regstudent ON job_applications.student_id = regstudent.id
                    WHERE job_applications.student_id = $studentId
                    AND regstudent.graduation_level = jobs.level
                    OR regstudent.major = jobs.major";
                    
$appliedJobsResult = mysqli_query($connection, $appliedJobsQuery);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Your Graduate Training Project - Applied Jobs</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
        }

        .applied-jobs-panel {
            margin-top: 100px;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
        <a class="navbar-brand text-white" href="student_dashboard.php" style="padding-left: 45px;">
            <img src="images/umkc.png" alt="Logo" width="270" height="70">
        </a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="applyJob.php">Job Apply</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="searchJob.php">Search Job</a>
                </li>
				<li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="appliedJobs.php">Applied Job</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="studentProfile.php"><?php echo $student_name; ?>'s Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Applied Jobs Panel -->
    <div class="container applied-jobs-panel">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center">Applied Jobs</h4>

                        <!-- Applied Jobs Table -->
                        <?php
                        if ($appliedJobsResult && mysqli_num_rows($appliedJobsResult) > 0) {
                            echo '<table class="table table-bordered">';
                            echo '<thead>';
                            echo '<tr>';
                            echo '<th>Job Title</th>';
                            echo '<th>Graduation</th>';
                            echo '<th>Skill Required</th>';
                            echo '<th>Graduate Students</th>';
                            echo '<th>Contact Details</th>';
                            echo '<th>Profile</th>';
                            echo '<th>Company</th>';
                            echo '<th>Place</th>';
                            echo '<th>Term</th>';
                            echo '<th>Level</th>';
                            echo '<th>Position</th>';
                            echo '<th>Major</th>';
                            echo '<th>Apply Date</th>';
                            echo '<th>Resume</th>';  // New column for download link
                            echo '<th>Status</th>';  // New column for status
                            echo '<th>Action</th>';
                            echo '</tr>';
                            echo '</thead>';
                            echo '<tbody>';

                            while ($row = mysqli_fetch_assoc($appliedJobsResult)) {
                                echo '<tr>';
                                echo '<td>' . $row['jobtitle'] . '</td>';
                                echo '<td>' . $row['graduation'] . '</td>';
                                echo '<td>' . $row['skillrequired'] . '</td>';
                                echo '<td>' . $row['graduateStd'] . '</td>';
                                echo '<td>' . $row['contact_details'] . '</td>';
                                echo '<td>' . $row['profile'] . '</td>';
                                echo '<td>' . $row['company'] . '</td>';
                                echo '<td>' . $row['place'] . '</td>';
                                echo '<td>' . $row['term'] . '</td>';
                                echo '<td>' . $row['level'] . '</td>';
                                echo '<td>' . $row['position'] . '</td>';
                                echo '<td>' . $row['major'] . '</td>';
                                echo '<td>' . $row['apply_date'] . '</td>';
                                // Display download link for the resume
                                echo '<td><a href="' . $row['resume'] . '" class="btn btn-outline-warning btn-sm" download>Download</a></td>';
                                // Display status
                                echo '<td>';
                                if ($row['status'] == 0) {
                                    echo '<span class="badge badge-warning">Not Reviewed</span>';
                                } else {
                                    echo '<span class="badge badge-success">Reviewed</span>';
                                }
                                echo '</td>';
                                echo '<td><a href="cancelApplication.php?job_id=' . $row['id'] . '" class="btn btn-outline-danger btn-sm">Cancel</a></td>';
                                echo '</tr>';
                            }

                            echo '</tbody>';
                            echo '</table>';
                        } else {
                            echo '<p class="text-center">You have not applied to any jobs yet.</p>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
