<?php
// Start the session to access session variables
session_start();

// Include the database connection file
include("db_connect.php");

// Check if student is logged in
if (!isset($_SESSION['student_email'])) {
    // If not logged in, redirect to login page
    header("Location: LoginStudent.php");
    exit();
}

// Get student name from session
$student_name = $_SESSION['student_name'];

// Function to display available jobs based on search criteria
function displayJobs($connection, $searchCriteria)
{
    $sql = "SELECT j.* FROM jobs j
            INNER JOIN regstudent r ON j.level = r.graduation_level OR j.major = r.major
            WHERE j.jobtitle LIKE '%$searchCriteria%' OR j.graduation LIKE '%$searchCriteria%' 
                OR j.skillrequired LIKE '%$searchCriteria%' OR j.graduateStd LIKE '%$searchCriteria%'
                OR j.contact_details LIKE '%$searchCriteria%' OR j.profile LIKE '%$searchCriteria%'
                OR j.company LIKE '%$searchCriteria%' OR j.place LIKE '%$searchCriteria%'";

    $result = mysqli_query($connection, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        echo '<table class="table table-bordered">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>ID</th>';
        echo '<th>Job Title</th>';
        echo '<th>Graduation</th>';
        echo '<th>Skill Required</th>';
        echo '<th>Graduate Students</th>';
        echo '<th>Contact Details</th>';
        echo '<th>Profile</th>';
        echo '<th>Company</th>';
        echo '<th>Place</th>';
        echo '<th>Term</th>';
        echo '<th>Level</th>';
        echo '<th>Position</th>';
        echo '<th>Major</th>';
        echo '<th>Action</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        while ($row = mysqli_fetch_assoc($result)) {
            echo '<tr>';
            echo '<td>' . $row['id'] . '</td>';
            echo '<td>' . $row['jobtitle'] . '</td>';
            echo '<td>' . $row['graduation'] . '</td>';
            echo '<td>' . $row['skillrequired'] . '</td>';
            echo '<td>' . $row['graduateStd'] . '</td>';
            echo '<td>' . $row['contact_details'] . '</td>';
            echo '<td>' . $row['profile'] . '</td>';
            echo '<td>' . $row['company'] . '</td>';
            echo '<td>' . $row['place'] . '</td>';
            echo '<td>' . $row['term'] . '</td>';
            echo '<td>' . $row['level'] . '</td>';
            echo '<td>' . $row['position'] . '</td>';
            echo '<td>' . $row['major'] . '</td>';
            echo '<td><a href="applyJob.php?job_id=' . $row['id'] . '" class="btn btn-outline-success">Apply</a></td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';
    } else {
        echo '<p class="text-center">No jobs found.</p>';
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Your Graduate Training Project - Search Jobs</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
        }

        .search-jobs-panel {
            margin-top: 100px;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
        <a class="navbar-brand text-white" href="student_dashboard.php" style="padding-left: 45px;">
            <img src="images/umkc.png" alt="Logo" width="270" height="70">
        </a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="applyJob.php">Job Apply</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="searchJob.php">Search Job</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="appliedJobs.php">Applied Job</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="studentProfile.php"><?php echo $student_name; ?>'s Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Search Jobs Panel -->
    <div class="container search-jobs-panel">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center">Search Jobs</h4>

                        <!-- Search Form -->
                        <form action="" method="get" class="mb-3">
                            <div class="form-group">
                                <label for="searchCriteria">Search Criteria:</label>
                                <input type="text" class="form-control" id="searchCriteria" name="searchCriteria" placeholder="Enter any criteria">
                            </div>
                            <button type="submit" class="btn btn-outline-primary">Search</button>
                        </form>

                        <!-- Display Jobs -->
                        <?php
                        // Display available jobs based on search criteria
                        $searchCriteria = isset($_GET['searchCriteria']) ? $_GET['searchCriteria'] : '';
                        displayJobs($connection, $searchCriteria);
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
