<?php
$host = "localhost";
$dbname = "umkc";
$username = "root"; // Your database username
$password = "";     // Your database password

// Create a database connection
$connection = mysqli_connect($host, $username, $password, $dbname);

// Check the connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
