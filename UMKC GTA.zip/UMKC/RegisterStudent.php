<?php
// Include the database connection file
include("db_connect.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $name = $_POST['name'];
    $lastname = $_POST['lastname'];
    $mailid = $_POST['mailid'];
    $password = $_POST['password'];
    $graduation_level = $_POST['graduation_level'];
    $major = $_POST['major'];
    $date_of_birth = $_POST['date_of_birth'];
    $IntStudent = $_POST['IntStudent'];
    $toefl_score = $_POST['toefl_score'];
    $grad_asst_score = $_POST['grad_asst_score'];
    $phone = $_POST['phone'];

    // Example SQL query to insert data into the 'regstudent' table
    $sql = "INSERT INTO regstudent (name, lastname, mailid, password, graduation_level, major, date_of_birth, IntStudent, toefl_score, grad_asst_score, phone) 
            VALUES ('$name', '$lastname', '$mailid', '$password', '$graduation_level', '$major', '$date_of_birth', '$IntStudent', '$toefl_score', '$grad_asst_score', '$phone')";

    // Execute the query
    if (mysqli_query($connection, $sql)) {
        // Registration successful, redirect to success page
        header("Location: success_std_register.php");
        exit();
    } else {
        // Registration failed, redirect to error page
        header("Location: error_student_register.php");
        exit();
    }
} else {
    // Redirect to an error page if accessed without submitting the form
    header("Location: error_student_register.php");
    exit();
}
?>
