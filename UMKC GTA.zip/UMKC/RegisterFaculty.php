<?php
// Include the database connection file
include("db_connect.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $faculty_name = $_POST['faculty_name'];
    $faculty_email = $_POST['faculty_email'];
    $faculty_password = $_POST['faculty_password'];
    $faculty_department = $_POST['faculty_department'];
    $faculty_phone = $_POST['faculty_phone'];

    $sql = "INSERT INTO faculty (name, email, password, department, phone) 
            VALUES ('$faculty_name', '$faculty_email', '$faculty_password', '$faculty_department', '$faculty_phone')";

    // Execute the query
    if (mysqli_query($connection, $sql)) {
        // Registration successful, redirect to success page
        header("Location: success_fac_register.php");
        exit();
    } else {
        // Registration failed, redirect to error page
        header("Location: error_fac_register.php");
        exit();
    }
} else {
    // Redirect to an error page if accessed without submitting the form
    header("Location: error_fac_register.php");
    exit();
}
?>
