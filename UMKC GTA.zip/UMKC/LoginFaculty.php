<?php
// Include the database connection file
include("db_connect.php");
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $email = $_POST['faculty_email'];
    $password = $_POST['faculty_password'];

    // Example SQL query to check faculty credentials
    $sql = "SELECT * FROM faculty WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($connection, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        // Login successful
        $row = mysqli_fetch_assoc($result);

        // Store faculty data in session
        $_SESSION['faculty_id'] = $row['faculty_id'];
        $_SESSION['faculty_name'] = $row['name'];
        $_SESSION['faculty_email'] = $row['email'];
        $_SESSION['faculty_department'] = $row['department'];
        $_SESSION['faculty_phone'] = $row['phone'];

        // Redirect to faculty dashboard
        header("Location: faculty_dashboard.php");
        exit();
    } else {
        // Login failed
        header("Location: loginFacFail.php");
        exit();
    }
} else {
    // Redirect to an error page if accessed without submitting the form
    header("Location: loginFacFail.php");
    exit();
}
?>
