<?php
// Include the database connection file
include("db_connect.php");

// Check if the required parameters are set
if (isset($_POST['term']) && isset($_POST['level']) && isset($_POST['position']) && isset($_POST['major']) && isset($_POST['id'])) {
    // Sanitize input data to prevent SQL injection
    $id = mysqli_real_escape_string($connection, $_POST['id']);
    $term = mysqli_real_escape_string($connection, $_POST['term']);
    $level = mysqli_real_escape_string($connection, $_POST['level']);
    $position = mysqli_real_escape_string($connection, $_POST['position']);
    $major = mysqli_real_escape_string($connection, $_POST['major']);

    // Fetch job details from the database
    $query = "SELECT * FROM jobs WHERE term='$term' AND level='$level' AND position='$position' AND major='$major' AND id='$id'";
    $result = mysqli_query($connection, $query);

    if ($result) {
        // Fetch the job details
        $jobDetails = mysqli_fetch_assoc($result);

        // Output job details as JSON
        echo json_encode($jobDetails);
    } else {
        // Handle the database error
        echo "Error fetching job details: " . mysqli_error($connection);
    }
} else {
    // Handle missing parameters
    echo "Missing parameters";
}

// Close the database connection
mysqli_close($connection);
?>
