<?php
// Start the session to access session variables
session_start();

// Check if student is logged in
if (!isset($_SESSION['student_email'])) {
    // If not logged in, redirect to login page
    header("Location: LoginStudent.php");
    exit();
}
include("db_connect.php");
// Get student name from session
$student_name = $_SESSION['student_name'];
$job_id = $_SESSION['jobs_id'];

// Fetch jobs data from the database
$query = "SELECT * FROM jobs";
$result = mysqli_query($connection, $query);

// Check if the query was successful
if (!$result) {
    die("Database query failed: " . mysqli_error($connection));
}

// Fetch the job details into an array
$jobs = [];
while ($row = mysqli_fetch_assoc($result)) {
    $jobs[] = $row;
}

// Close the database connection
mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Your Graduate Training Project - Student Dashboard</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
        }

        .dashboard-panel {
            margin-top: 100px;
            text-align: center;
        }
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
        <a class="navbar-brand text-white" href="student_dashboard.php" style="padding-left: 45px;">
            <img src="images/umkc.png" alt="Logo" width="270" height="70">
        </a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="applyJob.php">Job Apply</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="searchJob.php">Search Job</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="appliedJobs.php">Applied Job</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="studentProfile.php"><?php echo $student_name; ?>'s Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white font-weight-bold" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Student Dashboard Panel -->
    <div class="container dashboard-panel">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-success">Welcome, <?php echo $student_name; ?>!</h4>
                        <p class="card-text text-dark">You are now logged in to your student dashboard.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
    // Check if there are stored job details in local storage
    var storedJobDetails = localStorage.getItem('jobDetails');
    if (storedJobDetails) {
        // Parse the stored job details
        var jobDetails = JSON.parse(storedJobDetails);

        // Log the jobDetails to the console
        console.log(jobDetails);

        // Redirect to apply.php with stored job details
        var job_id = <?php echo $row['id']; ?>
        window.location.href = 'applyJob.php?job_id=' + jobDetails['id']; // Fix the property name for job ID

        // Clear the stored job details in local storage
        localStorage.removeItem('jobDetails');
    }
</script>


</body>

</html>
